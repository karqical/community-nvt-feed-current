# 替换gvmd
tar -zxvf gvmd.tar.gz -C /home/gvmd/
cp -r /home/gvmd/* /var/lib/gvm/data-objects/gvmd/